# Learn and Earn AI

English-language coding education website with course pages, a browser JavaScript playground, project/library pages, responsive UI, and Supabase authentication integration.

- Versa and the related visual-block prototype have been removed.
- Wamia AI is switched off; no paid AI API is used.
- Email/password and Google login are wired to Supabase, pending your one-time provider setup.
- Deployment target: Vercel static hosting.

**Start here:** read [SETUP-GUIDE.md](SETUP-GUIDE.md) before deployment. Authentication will not work until you add your Supabase URL/public anon key and configure Google OAuth.
