
(() => {
  const ready = () => window.supabase && window.SUPABASE_URL &&
    !window.SUPABASE_URL.includes('YOUR-PROJECT') &&
    window.SUPABASE_ANON_KEY && !window.SUPABASE_ANON_KEY.includes('YOUR_');
  let client;
  if (ready()) client = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
  const msg = (s) => { const el=document.getElementById('auth-message') || document.getElementById('reset-message') || document.getElementById('finish-message'); if(el) el.textContent=s; };
  const configNotice = () => msg('Authentication is not configured yet. Follow SETUP-GUIDE.md to connect your Supabase project.');
  const goGoogle = async () => {
    if(!client) return configNotice();
    const {error}=await client.auth.signInWithOAuth({provider:'google', options:{redirectTo:location.origin+'/settings.html'}});
    if(error) msg(error.message);
  };
  document.getElementById('google-login')?.addEventListener('click',goGoogle);
  const login=document.querySelector('[data-auth="login"]');
  login?.addEventListener('submit',async e=>{
    e.preventDefault(); if(!client) return configNotice();
    const f=login.querySelectorAll('input'); msg('Signing in…');
    const {data,error}=await client.auth.signInWithPassword({email:f[0].value,password:f[1].value});
    if(error) return msg(error.message);
    location.href='settings.html';
  });
  const signup=document.querySelector('[data-auth="signup"]');
  signup?.addEventListener('submit',async e=>{
    e.preventDefault(); if(!client) return configNotice();
    const f=signup.querySelectorAll('input'); msg('Creating account…');
    const {data,error}=await client.auth.signUp({email:f[1].value,password:f[2].value,options:{data:{display_name:f[0].value},emailRedirectTo:location.origin+'/settings.html'}});
    if(error) return msg(error.message);
    msg(data.session?'Account created. Opening your workspace…':'Check your email to verify your account, then sign in.');
    if(data.session) location.href='settings.html';
  });
  const reset=document.querySelector('[data-auth="reset-request"]');
  reset?.addEventListener('submit',async e=>{
    e.preventDefault(); if(!client) return configNotice();
    msg('Sending password reset email…');
    const {error}=await client.auth.resetPasswordForEmail(reset.querySelector('input').value,{redirectTo:location.origin+'/reset-password.html'});
    msg(error?error.message:'If an account exists for that email, a reset link has been sent.');
  });
  const finish=document.querySelector('[data-auth="reset-finish"]');
  finish?.addEventListener('submit',async e=>{
    e.preventDefault(); if(!client) return configNotice();
    const password=finish.querySelector('input[name="password"]').value;
    msg('Updating password…');
    const {error}=await client.auth.updateUser({password});
    msg(error?error.message:'Password updated. You can now sign in.');
  });
  window.LEA_AUTH={client};
})();
