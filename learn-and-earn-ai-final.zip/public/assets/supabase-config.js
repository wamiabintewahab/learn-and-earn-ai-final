// Add your Supabase project values here after creating a project.
// These two values are public by design. NEVER put a service_role key here.
window.SUPABASE_URL = 'https://YOUR-PROJECT.supabase.co';
window.SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
