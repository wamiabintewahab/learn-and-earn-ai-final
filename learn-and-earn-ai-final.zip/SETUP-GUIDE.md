# Learn and Earn AI — Setup guide

This build removes Versa completely and keeps Wamia AI switched off. The interface is English. It uses Supabase for account authentication and Vercel for static hosting.

## What is already in this project
- Responsive learning platform pages and course dashboard.
- Course/library/project pages and browser JavaScript playground.
- Email/password sign-up and sign-in integration.
- Google OAuth sign-in integration (requires one-time Google + Supabase setup).
- Email verification and password reset flows through Supabase Auth.
- Wamia AI disabled; no AI API key or paid AI subscription is used.
- Versa removed from the navigation and project.

## Important: one-time account setup is required
I cannot create or verify accounts in your name, accept Google's/Supabase's terms for you, or obtain your private OAuth credentials. These steps must be done by you. The code is prepared for them.

### A. Create your Supabase project
1. Visit https://supabase.com/ and sign up (you may use GitHub).
2. Click **New project**. Name it `learn-and-earn-ai`.
3. Choose a strong database password and save it privately.
4. Wait for the project to finish creating.
5. In the Supabase project, open **Project Settings → API**.
6. Copy the **Project URL** and the **anon/public key**.
7. Open `public/assets/supabase-config.js` in this project.
8. Replace `https://YOUR-PROJECT.supabase.co` with the Project URL.
9. Replace `YOUR_SUPABASE_ANON_KEY` with the anon/public key.
   - Never paste the `service_role` key into frontend files or GitHub.

### B. Enable email sign-up
1. In Supabase open **Authentication → Providers → Email**.
2. Ensure Email provider is enabled.
3. Keep email confirmation enabled for public accounts.
4. Under **Authentication → URL Configuration**, set:
   - Site URL: your final Vercel website URL (you can update this after deployment).
   - Redirect URLs: add `http://localhost:3000/**` and your Vercel domain with `/**`.

### C. Enable Continue with Google
1. Go to https://console.cloud.google.com/ and sign in with your Google account.
2. Create a Google Cloud project.
3. Open **APIs & Services → OAuth consent screen** and configure the app details.
4. Open **Credentials → Create Credentials → OAuth client ID → Web application**.
5. Add the Supabase callback URL shown in Supabase **Authentication → Providers → Google** as an Authorized redirect URI.
6. Copy the Google Client ID and Client Secret into the Google provider settings in Supabase.
7. Enable the Google provider and save.
8. In Supabase URL Configuration, add your local and deployed redirect URLs.
Google may require consent-screen verification or test-user configuration depending on the app status. The Google Client Secret belongs only in Supabase, never in this project or GitHub.

### D. Publish on Vercel (free tier)
1. Push this project to a GitHub repository (you already have GitHub; you can create a new repository or replace the old project after backing it up).
2. Visit https://vercel.com/ and sign in with GitHub.
3. Click **Add New → Project**, choose the Learn and Earn AI repository.
4. Framework preset: **Other**. Build command: leave empty. Output directory: `public`.
5. Click **Deploy**.
6. Copy the deployed URL. Return to Supabase → Authentication → URL Configuration and set the Site URL to this Vercel URL; add it to Redirect URLs.
7. In Google Cloud OAuth client, add the Vercel domain as an Authorized JavaScript origin if requested by Google's setup screen. Keep the Supabase callback URI as the redirect URI.

### E. Test after deployment
- Create a new account with an email you can access; confirm the verification email.
- Sign out, then sign in with email/password.
- Test **Continue with Google**.
- Test **Forgot password** and follow the email link.
- Test the course pages and JavaScript playground.
If a login button reports that authentication is not configured, recheck the two values in `supabase-config.js` and redeploy.

## Run locally
You need Node.js 18+.
1. Extract this ZIP.
2. Open a terminal in the project folder.
3. Run `npx serve public -l 3000` (or `npm start`).
4. Open http://localhost:3000.

## Boundaries (honest status)
- Supabase/Google sign-in cannot work until you complete the provider setup and enter your own project values.
- Email delivery and password recovery depend on Supabase Auth email settings and provider limits. Configure custom SMTP if you later need reliable production email delivery.
- This is a static learning platform with Supabase authentication. Course progress is still stored locally in this starter; account-synced progress and multi-user database tables are not included yet.
- The playground runs JavaScript in a browser sandbox. Python and Java execution need a separate isolated code-runner service.
- Wamia AI is intentionally off. No paid AI provider is connected.
- Vercel and Supabase free plans have quotas and terms that can change; free hosting is not a promise of unlimited usage.
- Before a public production launch, review privacy/terms, accessibility, database access policies (RLS), abuse protection, and test with real users.
